:mod:`webhelpers.constants`
================================================

.. automodule:: webhelpers.constants

.. currentmodule:: webhelpers.constants

Countries
---------

.. autofunction:: country_codes

States & Provinces
------------------

.. autofunction:: us_states
.. autofunction:: us_territories
.. autofunction:: canada_provinces
.. autofunction:: uk_counties

Deprecations
------------

The timezone helpers were removed in WebHelpers 0.6.  Install the PyTZ
package if you need them.
