:mod:`webhelpers.textile`
=========================

``webhelpers.textile`` is a copy of Textile, used by
``webhelpers.html.converters.textilize()``.  See the Textile_ site for
documentation on the Textile format and this module.

.. _Textile:  http://textile.org/

..
    .. automodule:: webhelpers.textile

    .. currentmodule:: webhelpers.textile
