History
%%%%%%%

WebHelpers was originally created as a utility package for Pylons. Many of the
helpers were ported from Ruby on Rails. Version 0.6 introduced the HTML tag
builder and deprecated the rails helpers; new subpackages were added to replace
the rails helpers. Version 1.0 builds on this with many additional helpers.

WebHelpers has been in a soft feature freeze since 1.0. Only bugfixes, small
enhancements, and compatibility with new Pylons Project frameworks are likely
to be accepted. 
